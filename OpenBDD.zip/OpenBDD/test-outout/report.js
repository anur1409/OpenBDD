$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/Anurag/Downloads/Compressed/Anurag (5)/OpenBDD/src/main/java/Features/OpenWeather.feature");
formatter.feature({
  "line": 1,
  "name": "Open Weather",
  "description": "",
  "id": "open-weather",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Open Weather",
  "description": "",
  "id": "open-weather;open-weather",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User opens the Specified Browser",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User Navigates to Open Weather Map site",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "title of the Page is \"Сurrent weather and forecast - OpenWeatherMap\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "OpenWeatherMap Searchbutton is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "OpenWeatherMap Searchbutton is enabled",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "OpenWeatherMap cityField is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "OpenWeatherMap weatherLink is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "OpenWeatherMap weatherLink is enabled",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "OpenWeatherMap widgetLink is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "OpenWeatherMap widgetLink is enabled",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "OpenWeatherMap supportCentre is displayed",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "OpenWeatherMap supportCentre is enabled",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "Close the browser",
  "keyword": "Then "
});
formatter.match({
  "location": "OpenWeatherStepDefinition.User_opens_the_Specified_Browser()"
});
formatter.result({
  "duration": 6013745083,
  "status": "passed"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.User_Navigates_to_Open_Weather_Map_site()"
});
formatter.result({
  "duration": 10292408204,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Сurrent weather and forecast - OpenWeatherMap",
      "offset": 22
    }
  ],
  "location": "OpenWeatherStepDefinition.title_of_the_Page_is(String)"
});
formatter.result({
  "duration": 35253987,
  "status": "passed"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.openweathermap_Searchbutton_is_displayed()"
});
formatter.result({
  "duration": 531634,
  "error_message": "java.lang.NullPointerException\r\n\tat PageFactory.OpenWeatherHome.searchButtonDisplayed(OpenWeatherHome.java:27)\r\n\tat stepDefinitions.OpenWeatherStepDefinition.openweathermap_Searchbutton_is_displayed(OpenWeatherStepDefinition.java:54)\r\n\tat ✽.And OpenWeatherMap Searchbutton is displayed(C:/Users/Anurag/Downloads/Compressed/Anurag (5)/OpenBDD/src/main/java/Features/OpenWeather.feature:8)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.openweathermap_Searchbutton_is_enabled()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.openweathermap_cityField_is_displayed()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.openweathermap_weatherLink_is_displayed()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.openweathermap_weatherLink_is_enabled()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.openweathermap_widgetLink_is_displayed()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.openweathermap_widgetLink_is_enabled()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.openweathermap_supportCentre_is_displayed()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.openweathermap_supportCentre_is_enabled()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.Close_the_browser()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 19,
  "name": "Checking weather of an invalid city from OpenWeather",
  "description": "",
  "id": "open-weather;checking-weather-of-an-invalid-city-from-openweather",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "User is on OpenWeather Home Page",
  "keyword": "Given "
});
formatter.step({
  "line": 22,
  "name": "User enters city as \"XYZ\"",
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "User should get message as City not Found",
  "keyword": "Then "
});
formatter.step({
  "line": 24,
  "name": "Close the Browser",
  "keyword": "Then "
});
formatter.match({
  "location": "OpenWeatherStepDefinition.user_is_on_OpenWeather_Home_Page()"
});
formatter.result({
  "duration": 16711941152,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "XYZ",
      "offset": 21
    }
  ],
  "location": "OpenWeatherStepDefinition.user_enters_city_as(String)"
});
formatter.result({
  "duration": 1167859,
  "error_message": "java.lang.NullPointerException\r\n\tat PageFactory.OpenWeatherHome.cityFieldValue(OpenWeatherHome.java:73)\r\n\tat stepDefinitions.OpenWeatherStepDefinition.user_enters_city_as(OpenWeatherStepDefinition.java:43)\r\n\tat ✽.When User enters city as \"XYZ\"(C:/Users/Anurag/Downloads/Compressed/Anurag (5)/OpenBDD/src/main/java/Features/OpenWeather.feature:22)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.user_should_get_message_as_City_not_Found()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.close_the_Browser()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 27,
  "name": "Checking weather of a city from OpenWeather",
  "description": "",
  "id": "open-weather;checking-weather-of-a-city-from-openweather",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "User is on OpenWeather Home Page",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "User enters city as \"Mumbai\"",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "User should get waether of \"Mumbai\"",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "Close the Browser",
  "keyword": "Then "
});
formatter.match({
  "location": "OpenWeatherStepDefinition.user_is_on_OpenWeather_Home_Page()"
});
formatter.result({
  "duration": 4079309011,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Mumbai",
      "offset": 21
    }
  ],
  "location": "OpenWeatherStepDefinition.user_enters_city_as(String)"
});
formatter.result({
  "duration": 822372,
  "error_message": "java.lang.NullPointerException\r\n\tat PageFactory.OpenWeatherHome.cityFieldValue(OpenWeatherHome.java:73)\r\n\tat stepDefinitions.OpenWeatherStepDefinition.user_enters_city_as(OpenWeatherStepDefinition.java:43)\r\n\tat ✽.When User enters city as \"Mumbai\"(C:/Users/Anurag/Downloads/Compressed/Anurag (5)/OpenBDD/src/main/java/Features/OpenWeather.feature:30)\r\n",
  "status": "failed"
});
formatter.match({
  "arguments": [
    {
      "val": "Mumbai",
      "offset": 28
    }
  ],
  "location": "OpenWeatherStepDefinition.user_should_get_waether_of(String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.close_the_Browser()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 34,
  "name": "Testing the API",
  "description": "",
  "id": "open-weather;testing-the-api",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 36,
  "name": "User hits openWeather API",
  "keyword": "Given "
});
formatter.step({
  "line": 37,
  "name": "The Status Code is 200",
  "keyword": "Then "
});
formatter.match({
  "location": "OpenWeatherStepDefinition.User_hits_openWeather_API()"
});
formatter.result({
  "duration": 1822392293,
  "error_message": "java.lang.IllegalArgumentException: Invalid number of path parameters. Expected 4, was 0. Undefined path parameters are: z, x, y, e563eb5c6f1602063e2e9a32fdb70d2d.\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.codehaus.groovy.reflection.CachedConstructor.invoke(CachedConstructor.java:83)\r\n\tat org.codehaus.groovy.reflection.CachedConstructor.doConstructorInvoke(CachedConstructor.java:77)\r\n\tat org.codehaus.groovy.runtime.callsite.ConstructorSite$ConstructorSiteNoUnwrap.callConstructor(ConstructorSite.java:84)\r\n\tat org.codehaus.groovy.runtime.callsite.CallSiteArray.defaultCallConstructor(CallSiteArray.java:59)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.callConstructor(AbstractCallSite.java:238)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.callConstructor(AbstractCallSite.java:250)\r\n\tat io.restassured.internal.RequestSpecificationImpl.assertCorrectNumberOfPathParams(RequestSpecificationImpl.groovy:1341)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.codehaus.groovy.reflection.CachedMethod.invoke(CachedMethod.java:98)\r\n\tat groovy.lang.MetaMethod.doMethodInvoke(MetaMethod.java:325)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:1225)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:1034)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:822)\r\n\tat io.restassured.internal.RequestSpecificationImpl.invokeMethod(RequestSpecificationImpl.groovy)\r\n\tat org.codehaus.groovy.runtime.callsite.PogoInterceptableSite.call(PogoInterceptableSite.java:47)\r\n\tat org.codehaus.groovy.runtime.callsite.PogoInterceptableSite.callCurrent(PogoInterceptableSite.java:57)\r\n\tat org.codehaus.groovy.runtime.callsite.CallSiteArray.defaultCallCurrent(CallSiteArray.java:51)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.callCurrent(AbstractCallSite.java:157)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.callCurrent(AbstractCallSite.java:161)\r\n\tat io.restassured.internal.RequestSpecificationImpl.sendRequest(RequestSpecificationImpl.groovy:1228)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.codehaus.groovy.reflection.CachedMethod.invoke(CachedMethod.java:98)\r\n\tat groovy.lang.MetaMethod.doMethodInvoke(MetaMethod.java:325)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:1225)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:1034)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:822)\r\n\tat io.restassured.internal.RequestSpecificationImpl.invokeMethod(RequestSpecificationImpl.groovy)\r\n\tat org.codehaus.groovy.runtime.callsite.PogoInterceptableSite.call(PogoInterceptableSite.java:47)\r\n\tat org.codehaus.groovy.runtime.callsite.CallSiteArray.defaultCall(CallSiteArray.java:47)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.call(AbstractCallSite.java:116)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.call(AbstractCallSite.java:152)\r\n\tat io.restassured.internal.filter.SendRequestFilter.filter(SendRequestFilter.groovy:30)\r\n\tat io.restassured.filter.Filter$filter$0.call(Unknown Source)\r\n\tat org.codehaus.groovy.runtime.callsite.CallSiteArray.defaultCall(CallSiteArray.java:47)\r\n\tat io.restassured.filter.Filter$filter.call(Unknown Source)\r\n\tat io.restassured.internal.filter.FilterContextImpl.next(FilterContextImpl.groovy:72)\r\n\tat io.restassured.filter.time.TimingFilter.filter(TimingFilter.java:56)\r\n\tat io.restassured.filter.Filter$filter.call(Unknown Source)\r\n\tat org.codehaus.groovy.runtime.callsite.CallSiteArray.defaultCall(CallSiteArray.java:47)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.call(AbstractCallSite.java:116)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.call(AbstractCallSite.java:144)\r\n\tat io.restassured.internal.filter.FilterContextImpl.next(FilterContextImpl.groovy:72)\r\n\tat io.restassured.filter.FilterContext$next.call(Unknown Source)\r\n\tat org.codehaus.groovy.runtime.callsite.CallSiteArray.defaultCall(CallSiteArray.java:47)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.call(AbstractCallSite.java:116)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.call(AbstractCallSite.java:136)\r\n\tat io.restassured.internal.RequestSpecificationImpl.applyPathParamsAndSendRequest(RequestSpecificationImpl.groovy:1749)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.codehaus.groovy.reflection.CachedMethod.invoke(CachedMethod.java:98)\r\n\tat groovy.lang.MetaMethod.doMethodInvoke(MetaMethod.java:325)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:1225)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:1034)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:822)\r\n\tat io.restassured.internal.RequestSpecificationImpl.invokeMethod(RequestSpecificationImpl.groovy)\r\n\tat org.codehaus.groovy.runtime.callsite.PogoInterceptableSite.call(PogoInterceptableSite.java:47)\r\n\tat org.codehaus.groovy.runtime.callsite.PogoInterceptableSite.callCurrent(PogoInterceptableSite.java:57)\r\n\tat org.codehaus.groovy.runtime.callsite.CallSiteArray.defaultCallCurrent(CallSiteArray.java:51)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.callCurrent(AbstractCallSite.java:157)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.callCurrent(AbstractCallSite.java:185)\r\n\tat io.restassured.internal.RequestSpecificationImpl.applyPathParamsAndSendRequest(RequestSpecificationImpl.groovy:1755)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n\tat sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.codehaus.groovy.reflection.CachedMethod.invoke(CachedMethod.java:98)\r\n\tat groovy.lang.MetaMethod.doMethodInvoke(MetaMethod.java:325)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:1225)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:1034)\r\n\tat groovy.lang.MetaClassImpl.invokeMethod(MetaClassImpl.java:822)\r\n\tat io.restassured.internal.RequestSpecificationImpl.invokeMethod(RequestSpecificationImpl.groovy)\r\n\tat org.codehaus.groovy.runtime.callsite.PogoInterceptableSite.call(PogoInterceptableSite.java:47)\r\n\tat org.codehaus.groovy.runtime.callsite.PogoInterceptableSite.callCurrent(PogoInterceptableSite.java:57)\r\n\tat org.codehaus.groovy.runtime.callsite.CallSiteArray.defaultCallCurrent(CallSiteArray.java:51)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.callCurrent(AbstractCallSite.java:157)\r\n\tat org.codehaus.groovy.runtime.callsite.AbstractCallSite.callCurrent(AbstractCallSite.java:185)\r\n\tat io.restassured.internal.RequestSpecificationImpl.get(RequestSpecificationImpl.groovy:171)\r\n\tat io.restassured.internal.RequestSpecificationImpl.get(RequestSpecificationImpl.groovy)\r\n\tat io.restassured.RestAssured.get(RestAssured.java:778)\r\n\tat stepDefinitions.OpenWeatherStepDefinition.User_hits_openWeather_API(OpenWeatherStepDefinition.java:134)\r\n\tat ✽.Given User hits openWeather API(C:/Users/Anurag/Downloads/Compressed/Anurag (5)/OpenBDD/src/main/java/Features/OpenWeather.feature:36)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "OpenWeatherStepDefinition.The_Status_Code_is_200()"
});
formatter.result({
  "status": "skipped"
});
});