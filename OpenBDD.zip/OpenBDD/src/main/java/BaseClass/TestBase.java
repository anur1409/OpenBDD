package BaseClass;

import org.openqa.selenium.WebDriver;

public class TestBase {
	
	public static WebDriver driver;
	
	

}
