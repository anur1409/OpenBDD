package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import BaseClass.TestBase;

public class SearchPage extends TestBase {
	

	@FindBy(xpath = "//div[@class='alert alert-warning']")
	WebElement notFound;
	
	@FindBy(xpath = "//a[contains(text(),'Mumbai')]")
	WebElement cityPresent;
	
	public boolean notFoundDisplayed()
	{
	return notFound.isDisplayed();
	}
	

	public boolean cityPresentDisplayed()
	{
	return cityPresent.isDisplayed();
	}
	
	
	
	
}
