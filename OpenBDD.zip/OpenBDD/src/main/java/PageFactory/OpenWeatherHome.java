package PageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import BaseClass.TestBase;

public class OpenWeatherHome extends TestBase {
	
	@FindBy(xpath = "//button[@class='btn btn-orange']")
	WebElement searchButton;
	
	@FindBy(xpath = "//input[@placeholder='Your city name']")
	WebElement cityField;
	
	@FindBy(xpath = "//a[text()='Weather']")
	WebElement weatherLink;
	
	@FindBy(xpath = "//a[text()='Widgets']")
	WebElement widgetLink;
	
	@FindBy(xpath = "//a[@class='first-child']")
	WebElement supportCentre;
	
	public Boolean searchButtonDisplayed()
	{
	    return searchButton.isDisplayed();
	}
	
	public Boolean searchButtonEnabled()
	{
	    return searchButton.isEnabled();
	}
	
	public Boolean cityFieldDisplayed()
	{
	    return cityField.isDisplayed();
	}
	
	public Boolean weatherLinkDisplayed()
	{
	    return weatherLink.isDisplayed();
	}
	
	public Boolean weatherLinkEnabled()
	{
	    return weatherLink.isEnabled();
	}
	
	
	public Boolean widgetLinkDisplayed()
	{
	    return widgetLink.isDisplayed();
	}
	
	public Boolean widgetLinkEnabled()
	{
	    return widgetLink.isEnabled();
	}
	
	public Boolean supportCentreDisplayed()
	{
	    return supportCentre.isDisplayed();
	}
	
	public Boolean supportCentreEnabled()
	{
	    return supportCentre.isEnabled();
	}
	
	public void cityFieldValue(String city)
	{
		cityField.sendKeys(city);
	
	}
	
	public void clickSearch()
	{
		searchButton.click();
	}
	
	
	
	
	

}
