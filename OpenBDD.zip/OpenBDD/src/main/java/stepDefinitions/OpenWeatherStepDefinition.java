package stepDefinitions;

import org.openqa.selenium.chrome.ChromeDriver;

import BaseClass.TestBase;
import PageFactory.OpenWeatherHome;
import PageFactory.SearchPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import junit.framework.Assert;

public class OpenWeatherStepDefinition extends TestBase{
	
	// WebDriver driver;
	OpenWeatherHome OWH = new OpenWeatherHome();
	SearchPage sp = new SearchPage(); 
	Response Resp ;
	
	 @Given("^User opens the Specified Browser$")
	 public void User_opens_the_Specified_Browser(){
	 System.setProperty("webdriver.chrome.driver","C:/Users/Anurag/Downloads/Compressed/Anurag (5)/OpenBDD/Drivers/chromedriver.exe");
	 driver = new ChromeDriver();
	 
	 }
	 
	 @Given("User is on OpenWeather Home Page$")
	 public void user_is_on_OpenWeather_Home_Page() {
	     // Write code here that turns the phrase above into concrete actions
		 driver.get("https://openweathermap.org/");
	 }
	 
	 @When("^User Navigates to Open Weather Map site$")
	 public void User_Navigates_to_Open_Weather_Map_site(){
		 driver.get("https://openweathermap.org/");
	}
	 
	 @When("^User enters city as \"([^\"]*)\"$")
	 public void user_enters_city_as(String city)  {
	     // Write code here that turns the phrase above into concrete actions
	     OWH.cityFieldValue(city);
	     OWH.clickSearch();
	 }
	 @Then("^title of the Page is \"(.*)\"$")
	 public void title_of_the_Page_is (String title){
		Assert.assertEquals(title, driver.getTitle());
	 }
	
	 @Then("^OpenWeatherMap Searchbutton is displayed$")
	 public void openweathermap_Searchbutton_is_displayed() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
	     Assert.assertTrue(OWH.searchButtonDisplayed());
	 }

	 @Then("^OpenWeatherMap Searchbutton is enabled$")
	 public void openweathermap_Searchbutton_is_enabled() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
	     Assert.assertTrue(OWH.searchButtonEnabled());
	 }

	 @Then("^OpenWeatherMap cityField is displayed$")
	 public void openweathermap_cityField_is_displayed() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 Assert.assertTrue(OWH.cityFieldDisplayed());
	 }

	 @Then("^OpenWeatherMap weatherLink is displayed$")
	 public void openweathermap_weatherLink_is_displayed() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 Assert.assertTrue(OWH.weatherLinkDisplayed());
	 }

	 @Then("^OpenWeatherMap weatherLink is enabled$")
	 public void openweathermap_weatherLink_is_enabled() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 Assert.assertTrue(OWH.weatherLinkEnabled());
	 }

	 @Then("^OpenWeatherMap widgetLink is displayed$")
	 public void openweathermap_widgetLink_is_displayed() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 Assert.assertTrue(OWH.widgetLinkDisplayed());
	 }

	 @Then("^OpenWeatherMap widgetLink is enabled$")
	 public void openweathermap_widgetLink_is_enabled() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 Assert.assertTrue(OWH.widgetLinkEnabled());
	 }

	 @Then("^OpenWeatherMap supportCentre is displayed$")
	 public void openweathermap_supportCentre_is_displayed() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 Assert.assertTrue(OWH.supportCentreDisplayed());
	 }

	 @Then("^OpenWeatherMap supportCentre is enabled$")
	 public void openweathermap_supportCentre_is_enabled() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 Assert.assertTrue(OWH.supportCentreEnabled());
	 }
	
	 @Then("^Close the browser$")
	 public void Close_the_browser() {
	 driver.close();
	 
	 }
	 
	 
	 @Then("^User should get message as City not Found$")
	 public void user_should_get_message_as_City_not_Found() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 Assert.assertTrue(sp.notFoundDisplayed());
	    
	 }

	 @Then("^Close the Browser$")
	 public void close_the_Browser() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
	     driver.close();
	 }

	 @Then("^User should get waether of \"([^\"]*)\"$")
	 public void user_should_get_waether_of(String arg1) throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
		 Assert.assertTrue(sp.cityPresentDisplayed());
	 }

	 @Given("^User hits openWeather API$")
	 public void User_hits_openWeather_API()
	 {
		 Resp = RestAssured.get("http://maps.openweathermap.org/maps/2.0/weather/TA2/{z}/{x}/{y}?date=1563110201000&\r\n" + 
				"opacity=0.9&fill_bound=true&appid={e563eb5c6f1602063e2e9a32fdb70d2d}");
		 
	 }
	 
	 
	 @Then("^The Status Code is 200$")
	 public void The_Status_Code_is_200()
	 {
		 Assert.assertEquals(200, Resp.getStatusCode());
	 
	 
	 }
}

